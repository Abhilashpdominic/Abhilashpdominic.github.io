ABHILASH P DOMINIC – PROFESSIONAL WEBSITE

index.html = complete responsive website
abhilash-p-dominic.jpg = profile photograph

For a normal web host: upload both files to the same folder.
For Google Sites: use the content and image as the design/content reference; Google Sites does not directly publish a custom HTML file as a whole website.

After obtaining a public URL, use Google Search Console to request indexing. Google decides when/if a page appears in search results.
